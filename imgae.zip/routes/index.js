const express = require('express')
const app = express()
const fs = require('fs')
const images = require('../app')
const { ObjectId } = require("mongodb")
const { uploadimage } = require('../controllers/userControllers')
const fileupload = require('express-fileupload')
const multer = require('multer');
var bodyParser = require("body-parser");
app.use(bodyParser.json());
var uploadsDir = __dirname + '/public';
app.use(fileupload)
const router = express.Router()

router.get('/get/:id', (req, res) => {
    const id = req.params.id
        images.findById(ObjectId(id))
            .exec(function (err, result) {
                if (err) {
                    console.log("err", err)
                } else {
                    res.status(200).json({
                        data: result, success: true
                    })
                }
            })
    })

    router.get('/', (req, res) => {
        images.find({}).exec(function(err, user) {
            if(err) throw err;
            if(!user) {
                res.json({ success: fale, message: 'User not found' });
            } else {
                res.json({ success: true, message: 'get details Successfully', data: user ,success:true });
            }
        })
    })
router.post('/', uploadimage, (req, res) => {
    console.log("Hello");
    console.log("req.body", req.file);
    console.log("req.body", req.body);
    const data = images({
        name:req.body.name,
        gmail:req.body.gmail,
        password:req.body.password,
        photo: req.file.filename,
        photo_path:"http://localhost:9600/user/" + req.file.filename
    })
    data.save((err) => {
        if(err){
            console.log(err)
        }
    })
    // console.log(req.file)
    res.send("Submit successful");
    // res.send(req.body)
    // photo: req.file.filename,
    // photo_path:"http://localhost:8600/user/" + req.file.filename
}
)
// router.post('/', uploadimage,(req, res) => {
//      (req, res, function (err) {
//         console.log("req.file---", req.file);
//         if (err) {
//             if (err.code === 'LIMIT_FILE_SIZE') {
//                 res.json({ success: false, message: 'Profile Image too large !!!' });
//             } else if (err.code === 'filetype') {
//                 res.json({ success: false, message: 'Invaild : Only jpeg, jpg and png supported !!!' });
//             } else {
//                 console.log(err);
//                 res.json({ success: false, message: 'Profile Image not upload !!!' });
//             }
//         } else {
//             if (!req.file) {
//                 res.json({ success: false, message: 'No file selected !!!' });
//             } else {
//                 let user = new images();


//                 user.name=req.body.name;
//                 user.gmail=req.body.gmail;
//                 user.password=req.body.password
//                 user.photo = req.file.filename;
//                 user.photo_path = "http://localhost:8600/user/"+req.file.filename;
//                 user.save(function (err) {
//                     if (err) {
//                         console.log(err.errors.name);
//                         if (err.errors.name) {
//                             res.json({ success: false, message: "Name is required" });
//                         }
//                         else {
//                             res.json({ success: false, message: err });
//                         }
//                     } else {
//                         res.json({ success: true, message: 'Registration Successfully' });
//                     }
//                 });
//             }
//         }
//     })

// })


router.put('/:id', uploadimage, async (req, res) => {
        console.log("past____-", req.body);
    images.findOne({_id: req.params.id}).exec((err, result) => {
        if(err) {
            console.log(err)
        } else {
            result.name = req.body.name,
            result.gmail = req.body.gmail,
            result.password = req.body.password

            // result.photo = req.file.filename;
            // result.photo_path = "http://localhost:9600/user/" + req.file.filename;

            result.save(function(err){
                if(err){
                    console.log(err);
                }
            }); 
            res.send("update")
        }
    })


})
router.delete("/:id", async (req, res) => {
    // images.find({ _id: req.params.id }).exec(function (err, ress) {
        // res.json({'data':ress})
        const user = await images.findByIdAndDelete(req.params.id);
        res.send(user)
        // console.log("ress.photo", ress[0].photo);
        // fs.unlink("public/"+ress[0].photo, async (err) => {
        //     if (err) throw err;
       
        // })
    })
// }),



module.exports = router